import { GamedataService } from '../gamedata.service';
import { GameComponent } from '../game/game.component';
import { ViewContainerRef } from '@angular/core';
import {
  Component,
  OnInit,ComponentFactoryResolver,AfterViewInit
} from '@angular/core';


@Component({
  selector: 'app-game-buttons',
  templateUrl: './game-buttons.component.html',
  styleUrls: ['./game-buttons.component.css']
})
export class GameButtonsComponent  implements OnInit,AfterViewInit{
 ref:ViewContainerRef;
 gameComponentInstance: GameComponent;
  constructor(private gamedataService:GamedataService,private componentFactoryResolver:ComponentFactoryResolver) {
    this.gameComponentInstance=new GameComponent(this.gamedataService,this.componentFactoryResolver);
  }

  ngOnInit() {
    
  }
  ngAfterViewInit(){}


/**function for starting game */
startGame() {

  this.gamedataService.gameTimer = setInterval(
    () => {
      this.IncrementCounter();
      this.gameComponentInstance.InjectComponent();

    }, 1000);
}


/**inscrement the game counter */
IncrementCounter() {
  this.gamedataService.gameCounter++;
}

/**
 * Pause the Game
 */
pauseGame() {
  clearInterval(this.gamedataService.gameTimer);   
}

/**
 * Reset the Game
 */
resetGame() {
  clearInterval(this.gamedataService.gameTimer);
  this.gamedataService.gameCounter=0;
  this.gameComponentInstance.clearView();
}


}
