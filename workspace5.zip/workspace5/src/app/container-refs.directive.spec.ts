import { ContainerRefsDirective } from './container-refs.directive';

describe('ContainerRefsDirective', () => {
  it('should create an instance', () => {
    const directive = new ContainerRefsDirective();
    expect(directive).toBeTruthy();
  });
});
