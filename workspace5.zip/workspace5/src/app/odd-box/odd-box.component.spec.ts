import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OddBoxComponent } from './odd-box.component';

describe('OddBoxComponent', () => {
  let component: OddBoxComponent;
  let fixture: ComponentFixture<OddBoxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OddBoxComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OddBoxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
