import { Component, OnInit } from '@angular/core';
import { GamedataService } from '../gamedata.service';

@Component({
  selector: 'app-odd-box',
  templateUrl: './odd-box.component.html',
  styleUrls: ['./odd-box.component.css']
})
export class OddBoxComponent implements OnInit {
counterValue:number;
  constructor(private gamedataService:GamedataService) {

   }

  ngOnInit() {
    this.counterValue=this.gamedataService.gameCounter;
  }

}
