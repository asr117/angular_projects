import { Directive,ViewContainerRef} from '@angular/core';
import { GamedataService } from './gamedata.service';

@Directive({
  selector: '[appContainerRefs]'
})
export class ContainerRefsDirective {

  constructor(ref:ViewContainerRef,private gamedataService:GamedataService) {
    this.gamedataService.containerRef=ref;
    console.log( this.gamedataService.containerRef);
   }

}
