import {
  Component,
  AfterViewInit,
  OnInit,
  ViewChild,
  TemplateRef,
  ViewContainerRef,
  ComponentFactoryResolver
} from '@angular/core';
import {
  OddBoxComponent
} from '../odd-box/odd-box.component';
import {
  EvenBoxComponent
} from '../even-box/even-box.component';
import {
  container
} from '@angular/core/src/render3';
import {
  GamedataService
} from '../gamedata.service';

@Component({
  selector: 'app-game',
  templateUrl: './game.component.html',
  styleUrls: ['./game.component.css']
})
export class GameComponent implements OnInit {
  oddBox;
  evenBox;
  counterValue: number = 0;
  constructor(private gamedataService: GamedataService, private componentFactoryResolver: ComponentFactoryResolver) {
    this.oddBox = this.componentFactoryResolver.resolveComponentFactory(OddBoxComponent);
    this.evenBox = this.componentFactoryResolver.resolveComponentFactory(EvenBoxComponent);

  }

  ngOnInit() {  }


  /**
   * Clear the container view
   */
  clearView() {
    this.gamedataService.containerRef.clear();
  }

/**inject component into container */
  InjectComponent() {
    if(this.gamedataService.gameCounter%2==0)  this.gamedataService.containerRef.createComponent(this.evenBox);
    else this.gamedataService.containerRef.createComponent(this.oddBox);
  }

}
