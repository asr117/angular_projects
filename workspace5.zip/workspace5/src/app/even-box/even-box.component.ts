import { Component, OnInit } from '@angular/core';
import { GamedataService } from '../gamedata.service';
@Component({
  selector: 'app-even-box',
  templateUrl: './even-box.component.html',
  styleUrls: ['./even-box.component.css']
})
export class EvenBoxComponent implements OnInit {

  counterValue:number;
  constructor(private gamedataService:GamedataService) {

   }

  ngOnInit() {
    this.counterValue=this.gamedataService.gameCounter;
  }

}
