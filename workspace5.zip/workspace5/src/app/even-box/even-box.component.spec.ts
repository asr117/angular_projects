import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EvenBoxComponent } from './even-box.component';

describe('EvenBoxComponent', () => {
  let component: EvenBoxComponent;
  let fixture: ComponentFixture<EvenBoxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EvenBoxComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EvenBoxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
