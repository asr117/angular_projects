import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { GameComponent } from './game/game.component';
import { GameButtonsComponent } from './game-buttons/game-buttons.component';
import { OddBoxComponent } from './odd-box/odd-box.component';
import { EvenBoxComponent } from './even-box/even-box.component';
import { ContainerRefsDirective } from './container-refs.directive';

@NgModule({
  declarations: [
    AppComponent,
    GameComponent,
    GameButtonsComponent,
    OddBoxComponent,
    EvenBoxComponent,
    ContainerRefsDirective
  ],
  entryComponents: [
    OddBoxComponent,
    EvenBoxComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
