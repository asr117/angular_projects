import { Injectable, ViewContainerRef } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class GamedataService {
  containerRef:ViewContainerRef;
  gameCounter: number=0;
  gameTimer;
  constructor() {
    this.gameCounter = 0;
   }
}
