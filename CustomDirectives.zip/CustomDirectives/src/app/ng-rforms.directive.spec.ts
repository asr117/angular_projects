import { NgRFormsDirective } from './ng-rforms.directive';

describe('NgRFormsDirective', () => {
  it('should create an instance', () => {
    const directive = new NgRFormsDirective();
    expect(directive).toBeTruthy();
  });
});
