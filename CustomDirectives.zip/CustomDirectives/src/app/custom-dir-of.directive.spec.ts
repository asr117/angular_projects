import { CustomDirOfDirective } from './custom-dir-of.directive';

describe('CustomDirOfDirective', () => {
  it('should create an instance', () => {
    const directive = new CustomDirOfDirective();
    expect(directive).toBeTruthy();
  });
});
