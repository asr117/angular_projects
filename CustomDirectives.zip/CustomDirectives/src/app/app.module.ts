import { BrowserModule, Title } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NgRFormsDirective } from './ng-rforms.directive';
import { RFormsDirective } from './rforms.directive';
import { GhostUIComponent } from './ghost-ui/ghost-ui.component';
import { GhostCompoDirective } from './ghost-ui/ghost-compo.directive';
import { DummyTemplateComponent } from './dummy-template/dummy-template.component';
import { DummyTemplateDirective } from './dummy-template/dummy-template.directive';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DummyTableRowComponent } from './dummy-table-row/dummy-table-row.component';
import { BColsComponent } from './b-cols/b-cols.component';
import { CustomDirOfDirective } from './custom-dir-of.directive';
import { ComponentCacheDirective } from './services/Directives/component-cache.directive';
@NgModule({
  declarations: [
    AppComponent,
    NgRFormsDirective,
    RFormsDirective,
    GhostUIComponent,
    GhostCompoDirective,
    DummyTemplateDirective,
    DummyTemplateComponent,
    DummyTableRowComponent,
    BColsComponent,
    CustomDirOfDirective,
    ComponentCacheDirective
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,BrowserAnimationsModule
  ],
  entryComponents:[DummyTableRowComponent,BColsComponent,DummyTemplateComponent],
  providers: [Title],
  bootstrap: [AppComponent]
})
export class AppModule { }
