import { Directive, Input, AfterViewInit, OnInit, ComponentFactoryResolver, TemplateRef, ViewContainerRef, OnChanges, ComponentRef } from '@angular/core';
import { DummyTemplateComponent } from 'src/app/dummy-template/dummy-template.component';
import { BColsComponent } from '../../b-cols/b-cols.component';
import { ComponentCacheService } from '../component-cache.service';
import { filter } from 'rxjs/operators';

@Directive({
  selector: '[appComponentCache]'
})
export class ComponentCacheDirective implements AfterViewInit,OnInit,OnChanges {

@Input('appComponentCache') appComponentCache:any[];

refIndex:number;

  constructor(private templateRef: TemplateRef < any > ,
    private viewContainer: ViewContainerRef,
    private componentFactoryResolver: ComponentFactoryResolver,
    private componentCacheService:ComponentCacheService) {  
       this.injectComponent();
  }
  

  ngOnChanges(changes: import("@angular/core").SimpleChanges): void {
  
this.refIndex=this.appComponentCache[1];
if(this.refIndex)   this.attachAgain(this.refIndex);
  }
  ngOnInit(): void {
this.refIndex=this.appComponentCache[1];
 }
  ngAfterViewInit(): void {
  }

  injectComponent() {
    console.log(this.appComponentCache);
    const componentFactory = this.componentFactoryResolver.resolveComponentFactory(DummyTemplateComponent);
    const componentFactory2 = this.componentFactoryResolver.resolveComponentFactory(BColsComponent);
    const viewContainerRef = this.viewContainer;
    viewContainerRef.clear();
    const cref2=viewContainerRef.createComponent(componentFactory2,0);
    const cref1 = viewContainerRef.createComponent(componentFactory,1);
    
    const cref3=viewContainerRef.createComponent(componentFactory,2);
    this.componentCacheService.setComponentRefs(cref1 );
    this.componentCacheService.setComponentRefs(cref2 );
    this.componentCacheService.setComponentRefs(cref3 );
    this.viewContainer.detach(0);
    this.viewContainer.detach(1);
    this.viewContainer.detach(2);
  }

  detachComponent(){

  }
   attachAgain(refIndex:number)
   {
    this.viewContainer.detach(0);
const componentRef:ComponentRef<any>=this.componentCacheService.ComponentRefs[refIndex];
this.viewContainer.insert(componentRef.hostView);


}
}
