import { ComponentCacheDirective } from './component-cache.directive';

describe('ComponentCacheDirective', () => {
  it('should create an instance', () => {
    const directive = new ComponentCacheDirective();
    expect(directive).toBeTruthy();
  });
});
