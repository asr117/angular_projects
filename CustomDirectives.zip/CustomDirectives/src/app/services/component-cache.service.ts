import { Injectable, Component, ComponentRef } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ComponentCacheService {
  detectChanges: boolean=true;
  detectChangesSource: BehaviorSubject<boolean>;
  detectChanges$:Observable<boolean>;
  
  ComponentRefs: ComponentRef<any>[]=[];
ComponentRefsSource: BehaviorSubject<ComponentRef<any>[]>;
ComponentRefs$:Observable<ComponentRef<any>[]>;
constructor() { 
  this.ComponentRefsSource=new BehaviorSubject(null);
  this.ComponentRefs$=this.ComponentRefsSource.asObservable();
this.detectChangesSource=new BehaviorSubject(true);
this.detectChanges$=this.detectChangesSource.asObservable();

}

getComponentRefs(){
return this.ComponentRefs$;
}

setComponentRefs(componentRef:ComponentRef<any>){
  this.ComponentRefs.push(componentRef);
  this.ComponentRefsSource.next(this.ComponentRefs);
}
deactivateChangeDetection() {
 this.detectChanges=false;
 this.detectChangesSource.next(this.detectChanges);
  }

  activateChangeDetection() {
    this.detectChanges=true;
    this.detectChangesSource.next(this.detectChanges);
  }


}
