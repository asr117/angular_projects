import { TemplateRef } from '@angular/core';
// tslint:disable-next-line: class-name
export class customRef extends TemplateRef<any> {
    elementRef: import("@angular/core").ElementRef<any>;   
     createEmbeddedView(context: any): import("@angular/core").EmbeddedViewRef<any> {
        throw new Error("Method not implemented.");
    }
constructor(public nativeElement: any){
    super();
    ElementRef
}
}
