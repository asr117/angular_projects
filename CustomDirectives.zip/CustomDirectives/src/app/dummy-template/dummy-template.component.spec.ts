import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DummyTemplateComponent } from './dummy-template.component';

describe('DummyTemplateComponent', () => {
  let component: DummyTemplateComponent;
  let fixture: ComponentFixture<DummyTemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DummyTemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DummyTemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
