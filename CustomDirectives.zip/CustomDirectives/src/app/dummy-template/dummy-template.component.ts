import { Component, OnInit, Input } from '@angular/core';
import { UsersService } from '../ghost-ui/users.service';
import { trigger, state, style, animate, transition } from '@angular/animations';
@Component({
  selector: 'app-dummy-template',
  templateUrl: './dummy-template.component.html',
  styleUrls: ['./dummy-template.component.scss'],
  animations: [
    trigger('fadeInOut', [
      state('void', style({
        opacity: 0
      })),
      transition('void <=> *', animate(1000)),
    ]),
  ]


})
export class DummyTemplateComponent implements OnInit {
  users: Array<any> = [];
  userHaveRights:boolean=true;
  @Input() currentState;
  constructor(private usersService: UsersService) { }

  ngOnInit() {
    this.usersService.getUsers()
    .subscribe((response) => {
      this.users = response;
    }, (err) => {
      console.log(err);
    });
  }
  public generateFake(count: number): Array<number> {
    const indexes = [];
    for (let i = 0; i < count; i++) {
      indexes.push(i);
    }
    return indexes;
  }

}
