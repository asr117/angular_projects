import {
  Directive,
  ElementRef,
  AfterViewInit,
  Input,
  TemplateRef,
  ViewContainerRef,
  Component,
  ComponentFactoryResolver,
  OnChanges,
  Renderer2
} from '@angular/core';
import {
  from,
  of ,
  Observable,
  BehaviorSubject,
  Subject
} from 'rxjs';
import {
  concatMap,
  delay,
  retryWhen,
  repeat,
  takeUntil
} from 'rxjs/operators';
import {
  DummyTableRowComponent
} from '../dummy-table-row/dummy-table-row.component';

@Directive({
  selector: '[appDummyTemplate]'
})


export class DummyTemplateDirective implements AfterViewInit, OnChanges {
  destroy$: Subject < boolean > = new Subject < boolean > ();
  width: number;
  moving_table_row: any;
  componentFactory;

  dataAvailable = false;
  dataAvailableSource = new BehaviorSubject < any > (false);
  dataAvailable$ = this.dataAvailableSource.asObservable();

  @Input() set appDummyTemplate(data: any) {
    this.width = data[1];
    this.dataAvailable = data[2];
    if (data[0]) {
      this.viewContainer.createEmbeddedView(this.templateRef);
    } else {
      this.viewContainer.clear();
    }
  }


  constructor(private templateRef: TemplateRef < any > ,
              private viewContainer: ViewContainerRef
  ) {
  
  }
  ngOnChanges(changes: import("@angular/core").SimpleChanges): void {
    this.destroy$.next(true);
  }
  ngAfterViewInit(): void {
    const content: any = this.templateRef.elementRef.nativeElement.nextElementSibling.children[0].cells;
    const initialContent: any = this.templateRef.elementRef.nativeElement.nextElementSibling.innerHTML;
    const bgCss = '#f6f7f8';
    const animation = 'loading 0.7s infinite linear';
    let background_image = ' -webkit-linear-gradient(right, #f6f7f8 0%, #edeef1 20%, #f6f7f8 40%, #f6f7f8 100%);linear-gradient(right, #f6f7f8 0%, #edeef1 20%, #f6f7f8 40%, #f6f7f8 100%)';
    let background_repeat: ' no-repeat';
    let i = 0;

   
// tslint:disable-next-line: variable-name
    let table_cols_length = content.length; 
    let tabLength=this.width;
    let table_row_start = '  <tr class="'+tabLength+'"">';
    let table_cols = '';




    //  GETTING INNER HTML READY
    for (i = 0; i < table_cols_length; i++) {
      table_cols += '<td  style="background:' + bgCss + ';transition-property: display;transition-duration: 0.6s;animation:' + animation + ';background-imageL'+background_image+'">loading... </td>';
    }
    let table_row_end = '</tr>';
    this.moving_table_row = table_row_start + table_cols + table_row_end;
    this.animateRow(initialContent, this.moving_table_row);
  }

  animateRow(initialContent, innerHtml: any) {
    const myArray = [1, 2, 3, 4];
    const dummy$: Observable < any >= from(myArray);
    dummy$
      .pipe(
        concatMap(item => of (item).pipe(delay(300))),
        takeUntil(this.destroy$)
      ).subscribe(
        timedItem => {
          this.templateRef.elementRef.nativeElement.nextSibling.innerHTML += this.moving_table_row;
        },
        (err) => console.log(err),
        () => {
          this.templateRef.elementRef.nativeElement.nextSibling.innerHTML = initialContent;
          if (this.dataAvailable === true) {
            this.animateRow(initialContent, innerHtml);
          } else {
            this.templateRef.elementRef.nativeElement.nextSibling.innerHTML = '';
            this.viewContainer.clear();
            this.viewContainer.createEmbeddedView(this.templateRef);
          }
        }
      );
  }

}
