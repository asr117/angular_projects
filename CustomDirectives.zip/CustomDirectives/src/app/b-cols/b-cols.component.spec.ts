import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BColsComponent } from './b-cols.component';

describe('BColsComponent', () => {
  let component: BColsComponent;
  let fixture: ComponentFixture<BColsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BColsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BColsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
