import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { ComponentCacheService } from '../services/component-cache.service';

@Component({
  selector: 'app-b-cols',
  templateUrl: './b-cols.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./b-cols.component.scss']
})
export class BColsComponent implements OnInit {
userdata: any[] = [{
  id: 1,
  name: 'User1',
  email: '',
  address: 'Address of user,city,state'
}, {
  id: 2,
  name: 'User2',
  email: 'abc2@gmail.com',
  address: 'Address of user,city,state'
}, {
  id: 3,
  name: 'User3',
  email: 'zzz@user3.com',
  address: 'Address of user,city,state'
}
,
{
  id: 4,
  name: 'User4',
  email: '',
  address: ''
}

];


  constructor(
    private changeDetectorRef: ChangeDetectorRef,
    private componentCacheService:ComponentCacheService) { }
  ngOnInit() {
    this.componentCacheService.detectChanges$.subscribe(
(condition)=>{
console.log(condition);

  if(condition===true) this.activateChangeDetection();
  else   this.deactivateChangeDetection();
}

    );
  }
  ngAfterContentChecked(): void {

  }
  abv() {
    console.log('a b col');
  }
  deactivateChangeDetection() {
    console.log("deactivated");
    
  // this.changeDetectorRef.detach();
  }

  activateChangeDetection() {
    
    console.log("activated");
  // this.changeDetectorRef.detectChanges();
  }

}
