import { Directive } from '@angular/core';

@Directive({
  selector: '[appNgRForms]'
})
export class NgRFormsDirective {

  constructor() { }

}
