import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GhostUIComponent } from './ghost-ui.component';

describe('GhostUIComponent', () => {
  let component: GhostUIComponent;
  let fixture: ComponentFixture<GhostUIComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GhostUIComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GhostUIComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
