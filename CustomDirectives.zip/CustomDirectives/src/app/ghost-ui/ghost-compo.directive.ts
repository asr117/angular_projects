import {
  Directive,
  ElementRef,
  ViewContainerRef,
  AfterViewInit,
  ViewChild,
  TemplateRef,
  ContentChild,
  Input,
  OnChanges
} from '@angular/core';
import {
  element
} from 'protractor';

@Directive({
  selector: '[appGhostCompo]'
})
export class GhostCompoDirective implements OnChanges {

  @ContentChild('ElemContainer', {
    read: ViewContainerRef,
    static: false
  }) ElemContainer: TemplateRef < any > ;
  @Input('appGhostCompo') appGhostCompo;

  constructor(private elementref: ViewContainerRef) {


  }


  ngOnChanges(changes: import("@angular/core").SimpleChanges): void {
 
    const content: any = this.elementref.element.nativeElement.innerHTML;

if(this.appGhostCompo===false){

  this.elementref.element.nativeElement. innerHTML =null;
  this.elementref.element.nativeElement.innerHTML = content; 
  }
  else {
    
    this.elementref.element.nativeElement.innerHTML = '';
    this.elementref.element.nativeElement.innerHTML += '<ng-template #ElemContainer></ng-template>';

    this.elementref.element.nativeElement.children[0].innerHTML = content;
    // console.log(this.elementref.element.nativeElement.children[0]);

    // this.ElemContainer.nativeElement.innerHTML = content;


    // console.log(this.elementref.element.nativeElement);
    let bgCss = '#f6f7f8';
    let animation = 'loading 1.7s infinite linear';
    let background_image = ' -webkit-linear-gradient(right, #f6f7f8 0%, #edeef1 20%, #f6f7f8 40%, #f6f7f8 100%);linear-gradient(right, #f6f7f8 0%, #edeef1 20%, #f6f7f8 40%, #f6f7f8 100%)';

    let background_repeat: ' no-repeat';
    for (const element of this.elementref.element.nativeElement.children[0].children) {


      element.style.background = bgCss;

      element.style.backgroundImage = background_image;
      element.style.backgroundRepeat = background_repeat;
      element.style.width = "144px";
      element.style.animation = animation;
    
    }
  }
}





}
