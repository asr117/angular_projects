import { GhostCompoDirective } from './ghost-compo.directive';

describe('GhostCompoDirective', () => {
  it('should create an instance', () => {
    const directive = new GhostCompoDirective();
    expect(directive).toBeTruthy();
  });
});
