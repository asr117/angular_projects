import { Component, OnInit, AfterViewInit, Input, ElementRef, ViewChild, ViewContainerRef } from '@angular/core';
import { UsersService } from './users.service';

@Component({
  selector: 'app-ghost-ui',
  templateUrl: './ghost-ui.component.html',
  styleUrls: ['./ghost-ui.component.scss']
})
export class GhostUIComponent implements OnInit,AfterViewInit {
  @ViewChild('appGhostCompo', { read: ViewContainerRef,static:false }) appGhostCompo:ViewContainerRef;
  
  ngAfterViewInit(): void {
// console.log(this.appGhostCompo.element.nativeElement.children);


  // 17
  }
  users: Array<any> = [];
  constructor(private usersService: UsersService) { }

  ngOnInit() {
    this.usersService.getUsers()
    .subscribe((response) => {
      this.users = response;
    }, (err) => {
      console.log(err);
    });
  }
  public generateFake(count: number): Array<number> {
    const indexes = [];
    for (let i = 0; i < count; i++) {
      indexes.push(i);
    }
    return indexes;
  }
}
