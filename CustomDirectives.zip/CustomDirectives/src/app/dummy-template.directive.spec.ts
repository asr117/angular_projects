import { DummyTemplateDirective } from './dummy-template/dummy-template.directive';

describe('DummyTemplateDirective', () => {
  it('should create an instance', () => {
    const directive = new DummyTemplateDirective();
    expect(directive).toBeTruthy();
  });
});
