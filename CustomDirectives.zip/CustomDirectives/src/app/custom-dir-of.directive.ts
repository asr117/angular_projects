import { Directive, TemplateRef, ViewContainerRef, Input } from '@angular/core';

@Directive({
  selector: '[appCustomDirOf]'
})
export class CustomDirOfDirective {
  dataArray:any[];
  @Input() set appCustomDirOf(data: any) {
    this.dataArray = data[1];
    console.log(this.dataArray);
    
    if (data[0]) {
      this.viewContainer.createEmbeddedView(this.templateRef);

    } else {
      this.viewContainer.clear();

    }
  }
  constructor(private templateRef: TemplateRef < any > ,
    private viewContainer: ViewContainerRef) {

      
     }

}
