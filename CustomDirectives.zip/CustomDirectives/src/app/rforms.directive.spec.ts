import { RFormsDirective } from './rforms.directive';

describe('RFormsDirective', () => {
  it('should create an instance', () => {
    const directive = new RFormsDirective();
    expect(directive).toBeTruthy();
  });
});
