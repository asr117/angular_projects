import { Component, ComponentFactoryResolver } from '@angular/core';
import { ComponentCacheService } from './services/component-cache.service';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'CustomDirectives';
  toState = 'fadeInOut';
  changeState(state: any) {
    this.toState = state;
  }
  ComponentIndex:number=0;
  constructor(
    private componentFactoryResolver: ComponentFactoryResolver,
    private componentCacheService:ComponentCacheService,
    private titleService: Title ) { 

  }

  attach(index:number){
this.ComponentIndex=index;
this.componentCacheService.getComponentRefs();

  }

  public setTitle( newTitle: string) {
    this.titleService.setTitle( 'Home');
  }
  detach(){
    this.componentCacheService.deactivateChangeDetection();
  }  
  attach1(){
    this.componentCacheService.activateChangeDetection();
  }
}
