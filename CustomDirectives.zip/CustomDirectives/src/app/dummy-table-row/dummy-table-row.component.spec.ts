import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DummyTableRowComponent } from './dummy-table-row.component';

describe('DummyTableRowComponent', () => {
  let component: DummyTableRowComponent;
  let fixture: ComponentFixture<DummyTableRowComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DummyTableRowComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DummyTableRowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
