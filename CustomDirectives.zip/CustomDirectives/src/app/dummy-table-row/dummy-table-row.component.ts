import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dummy-table-row',
  templateUrl: './dummy-table-row.component.html',
  styleUrls: ['./dummy-table-row.component.scss']
})
export class DummyTableRowComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
